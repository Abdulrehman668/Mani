لیسر منجھلا — Viewer Version (صرف دیکھنے کے لیے)

یہ Android Studio source project ہے، APK نہیں۔ APK بنانے کے لیے Android Studio میں فولڈر کھولیں، Gradle sync کریں، پھر Build > Build APK(s) منتخب کریں.

ایپ تیار کرنے والے: رانا عبدالرحمن سرور

Viewer میں ڈیٹا دیکھنے کے لیے Edit ورژن سے نکالا گیا JSON بیک اَپ منتخب کریں۔ دونوں الگ ایپس ہیں، اس لیے ڈیٹا خودبخود شیئر نہیں ہوتا۔
